# 🧮 Python Calculator

A simple command-line calculator built with Python. This tool allows users to perform basic arithmetic operations with ease.

## Features

- Addition, subtraction, multiplication, and division
- Handles both integers and decimal numbers
- User-friendly command-line interface
- Input validation and error handling

## Getting Started

### Prerequisites

- Python 3.x installed on your system

### Installation

1. **Clone the repository:**
    ```
    git clone https://github.com/yourusername/python-calculator.git
    cd python-calculator
    ```

2. **Run the calculator:**
    ```
    python calculator.py
    ```

## Usage

1. Run the script.
2. Follow the prompts to select an operation and enter numbers.
3. View the result and choose to perform another calculation or exit.

### Example

Select operation:

Add

Subtract

Multiply

Divide

Enter choice (1/2/3/4): 1
Enter first number: 5
Enter second number: 3
Result: 5 + 3 = 8

## Contributing

Contributions are welcome! Feel free to fork the repo and submit pull requests for improvements or new features.

## License

This project is licensed under the MIT License.

---

*Happy calculating!*
