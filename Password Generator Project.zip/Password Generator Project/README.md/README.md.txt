# 🔐 Python Password Generator

A simple Python application that generates strong, random passwords based on user-specified criteria. Enhance your online security by creating complex passwords with ease!

## Features

- Choose password length
- Optionally include uppercase letters, lowercase letters, digits, and special characters
- Ensures randomness and complexity for better security
- User-friendly command-line interface

## Prerequisites

- Python 3.x

## Installation

1. **Clone the repository:**
    ```
    git clone https://github.com/yourusername/python-password-generator.git
    cd python-password-generator
    ```

2. **Run the password generator:**
    ```
    python password_generator.py
    ```

## Usage

1. Run the script.
2. Follow the prompts to specify password length and which character types to include.
3. The generated password will be displayed on the screen.

### Example

Enter password length: 16
Include uppercase letters? (y/n): y
Include lowercase letters? (y/n): y
Include numbers? (y/n): y
Include special characters? (y/n): n
Generated password: aB9cD3eFgH1jKlMn
